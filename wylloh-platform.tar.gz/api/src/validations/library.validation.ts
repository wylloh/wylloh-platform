import Joi from 'joi';

// Library validation schemas
export const createLibrarySchema = Joi.object({
  name: Joi.string().required().min(1).max(100).trim(),
  description: Joi.string().optional().max(500).trim(),
  isPublic: Joi.boolean().optional().default(false),
  tags: Joi.array().items(Joi.string().trim()).optional(),
  contentIds: Joi.array().items(Joi.string().pattern(/^[0-9a-fA-F]{24}$/)).optional()
});

export const updateLibrarySchema = Joi.object({
  name: Joi.string().optional().min(1).max(100).trim(),
  description: Joi.string().optional().max(500).trim(),
  isPublic: Joi.boolean().optional(),
  tags: Joi.array().items(Joi.string().trim()).optional()
});

export const addContentToLibrarySchema = Joi.object({
  contentIds: Joi.array().items(Joi.string().pattern(/^[0-9a-fA-F]{24}$/)).required().min(1)
});

export const removeContentFromLibrarySchema = Joi.object({
  contentIds: Joi.array().items(Joi.string().pattern(/^[0-9a-fA-F]{24}$/)).required().min(1)
});

export const getLibrariesSchema = Joi.object({
  userId: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).optional(),
  isPublic: Joi.boolean().optional(),
  limit: Joi.number().integer().min(1).max(100).optional().default(20),
  offset: Joi.number().integer().min(0).optional().default(0),
  search: Joi.string().optional().max(100).trim(),
  tags: Joi.array().items(Joi.string().trim()).optional()
});

export const libraryIdSchema = Joi.object({
  libraryId: Joi.string().pattern(/^[0-9a-fA-F]{24}$/).required()
}); 