// ContentStreamPage module declaration
declare module '../pages/player/ContentStreamPage' {
  import React from 'react';
  const ContentStreamPage: React.FC;
  export default ContentStreamPage;
} 