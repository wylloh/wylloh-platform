import { Theme } from '@mui/material/styles';

declare const theme: Theme;
export default theme; 