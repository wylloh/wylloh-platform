import React from 'react';

declare const AppRoutes: React.FC;
export default AppRoutes; 